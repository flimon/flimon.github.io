#!/usr/bin/env python

'''
PySQM __init__ code
____________________________

Copyright (c) Mireia Nievas <mnievas[at]ucm[dot]es>

This file is part of PySQM.

PySQM is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

PySQM is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with PySQM.  If not, see <http://www.gnu.org/licenses/>.
'''

__author__ = "Mireia Nievas"
__copyright__ = "Copyright (c) 2014 Mireia Nievas"
__credits__ = [\
 "Mireia Nievas @ UCM",\
 "Jaime Zamorano @ UCM",\
 "Laura Barbas @ OAN",\
 "Pablo de Vicente @ OAN"\
 ]
__license__ = "GNU GPL v3"
__shortname__ = "PySQM"
__longname__ = "Python Sky Quality Meter pipeline"
__version__ = "0.3"
__maintainer__ = "Mireia Nievas"
__email__ = "mnievas[at]ucm[dot]es"
__status__ = "Development" # "Prototype", "Development", or "Production"

from types import ModuleType
import sys

