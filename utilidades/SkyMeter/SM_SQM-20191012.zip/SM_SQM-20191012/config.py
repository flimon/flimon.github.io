#!/usr/bin/env python

'''
PySQM configuration File.
____________________________

Copyright (c) Mireia Nievas <mnievas[at]ucm[dot]es>

This file is part of PySQM.

PySQM is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

PySQM is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with PySQM.  If not, see <http://www.gnu.org/licenses/>.

____________________________
Notes:

You may need to change the following variables to match your
observatory coordinates, instrumental properties, etc.

Python (v2.7) syntax is mandatory.
____________________________
'''


'''
-------------
SITE location
-------------
'''
_observatory_name = 'Mazariegos'
_observatory_latitude  = 42.025887
_observatory_longitude = -4.715738
_observatory_altitude  = 743
_observatory_horizon   = 10  # If Sun is below this altitude, the program will take data

_device_shorttype = 'SQM'    # Device (short)name for filenames
_device_type = 'SQM_LU'      # Device type. SQM_LE / SQM_LU
_device_id = _device_type + '-' + _observatory_name  # Long Device name. Should include the name of the observatory.
_device_locationname = 'Palencia/Spain - Mazariegos' # Device location in the world
_data_supplier = 'Fernando Limon (LFEA)'             # Data supplier (contact)
_device_addr = 'COM9'        # Default Adress of the device
_measures_to_promediate = 5  # Take the mean of N measures to remove jitter
_delay_between_measures = 20 # Delay between two measures. In seconds.
_cache_measures = 5          # Get N measures before writing on screen/file
_plot_each = 60              # Call the plot function each N measures.

'''
-------------------------------------
TimeZone of the site and the computer
-------------------------------------
'''

_local_timezone     = +1    # The real timezone of the site (without daylight saving)
_offset_calibration = -0.0  # magnitude = read_magnitude + offset
_reboot_on_connlost = False # Reboot if we loose connection

'''
---------------------------------------
System PATHs to save the data and plots
---------------------------------------
'''

# Monthly (permanent) data
monthly_data_directory = "C:\PySQM\Data"
# Daily (permanent) data
daily_data_directory   = monthly_data_directory+"/datos_diarios/"
# Daily (permanent) graph
daily_graph_directory = monthly_data_directory+"/graficos_diarios/"
# Current data, deleted each day.
current_data_directory = monthly_data_directory
# Current graph, deleted each day.
current_graph_directory = monthly_data_directory
# Summary with statistics for the night
summary_data_directory = monthly_data_directory

'''
---------------------------------
MYSQL database options (OPTIONAL)
---------------------------------
'''

# Set to True if you want to store data on a MySQL db.
_use_mysql = False
# Host (ip:port / localhost) of the MySQL engine.
_mysql_host = None
# User with write permission on the db.
_mysql_user = None
# Password for that user.
_mysql_pass = None
# Name of the database.
_mysql_database = None
# Name of the database table
_mysql_dbtable = None
# Port of the MySQL server.
_mysql_port = None

'''
----------------------------
PySQM data center (OPTIONAL)
----------------------------
'''

# Send the data to the data center
_send_to_datacenter = False

'''
---------------
Ploting options
---------------
'''

full_plot  = True       # Plot only date / full plot (datetime + sun alt)
limits_nsb = [15,22]    # Limits in Y-axis of the plot (Night Sky Background)
limits_time   = [17,9]  # Time (hours) for the beginning and the end of the session. (LOCALTIME)
limits_sunalt = [-80,5] # Limits in the Sun altitude for the plot. In degrees.

'''
-------------
Email options
-------------
'''
# Requires pysqm.email.py module. Not released yet!.
_send_data_by_email = False

